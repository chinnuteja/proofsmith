"""Shared tool-calling agent."""
