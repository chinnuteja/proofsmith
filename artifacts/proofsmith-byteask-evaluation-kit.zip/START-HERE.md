# Proofsmith evaluation kit

Real ByteAsk observations: 5/5. no demonstrated advantage. Additional purchases: $0.

Read docs/byteask-review.md for the product overview. Open experiments/byteask-comparison/live-v1-score/index.html for real results, patches, recorded tool output and gate receipts. Read docs/byteask-live-comparison.md. The separate v1/index.html shows fifteen authored offline controls; those are excluded from model scores. Five synthetic cases do not establish broad superiority.

Install on Linux/WSL with Python 3.12+, clang++, CMake and bubblewrap. In a virtual environment, run `pip install "./artifacts/proofsmith-0.2.0-py3-none-any.whl[mcp]"`. Then run `bash scripts/rescore_byteask_comparison.sh --out /tmp/proofsmith-real-recheck` to compile and evaluate the retained real patches afresh, without a model or account. Use a new output path. Read docs/verification-tool.md and docs/byteask-integration.md to use the CLI, MCP or CI gate on your own original/candidate pair.

Original collection records retain their original absolute paths. The offline rescorer rebases only a temporary copy and preserves transcript hashes. Recorded timings are machine-dependent. Hashes bind bytes, not authorship. No credentials or ByteAsk binary are included. This archive has not been published or sent.
