"""Static site renderer."""
